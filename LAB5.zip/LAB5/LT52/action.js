// khai bao cac action

export const tang = () => ({ type: 'TANG' });
export const giam = () => ({ type: 'GIAM' });