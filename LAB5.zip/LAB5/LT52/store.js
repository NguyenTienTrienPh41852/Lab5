import { createStore } from 'redux'
import demReducer from './reducer'
const store = createStore(demReducer)
export default store
