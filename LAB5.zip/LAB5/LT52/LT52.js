import { StyleSheet, Text, View } from 'react-native'
import React from 'react'
import { Provider } from 'react-redux'
import Viewapp from './Viewapp'
import store from './store'

const LT52 = () => {
  return (
   <Provider store={store}>
    <Viewapp/>
   </Provider>
  )
}

export default LT52

const styles = StyleSheet.create({})