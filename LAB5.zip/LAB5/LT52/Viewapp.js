import { Button, StyleSheet, Text, View } from 'react-native'
import React from 'react'
import { useSelector,useDispatch } from 'react-redux'
import { tang,giam } from './action'


const Viewapp = () => {
    const count = useSelector(state => state.dem);
    const dispatch =  useDispatch();

  return (
    <View>
      <Text>Dem: {count}</Text>
      <Button title='Tang' onPress={()=>dispatch(tang())}></Button>
      <Button title='Giam' onPress={()=>dispatch(giam())}></Button>
    </View>
  )
}

export default Viewapp

const styles = StyleSheet.create({})