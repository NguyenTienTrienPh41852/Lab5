import { createStore } from 'redux'
// khai bao cac action
const TANG = 'TANG';
const GIAM = 'GIAM';


const initState = {
    dem: 0
}
const demReducer = (state = initState, action) => {
    switch (action.type) {
        case TANG:
            return { ...state, dem: state.dem + 1 };
        case GIAM:
            return { ...state, dem: state.dem - 1 };
            default:
                return state
    }
}
const store = createStore(demReducer)
export default store
